# rag_retriever_chroma.py
# rag_retriever_chroma.py

import sys

try:
    import pysqlite3
    sys.modules["sqlite3"] = pysqlite3
    sys.modules["sqlite3.dbapi2"] = pysqlite3.dbapi2
except Exception:
    pass

import os
import uuid
from typing import List, Dict, Any, Optional
import numpy as np

import chromadb
from sentence_transformers import SentenceTransformer
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

# -----------------------------
# 1) Load documents from folder
# -----------------------------
def load_documents(data_dir: str) -> List[Any]:
    """
    Loads all *.txt recursively using DirectoryLoader + TextLoader.
    Returns LangChain Document objects with .page_content and .metadata.
    """
    loader = DirectoryLoader(
        data_dir,
        glob="**/*.txt",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"},
        show_progress=False,
    )
    docs = loader.load()
    print(f"[Loader] Loaded {len(docs)} documents from: {data_dir}")
    return docs


# -----------------------------
# 2) Chunking (TextSplitter)
# -----------------------------
def split_documents(documents: List[Any], chunk_size: int = 500, chunk_overlap: int = 200) -> List[Any]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", " ", ""],
    )
    chunks = splitter.split_documents(documents)
    print(f"[Chunking] Split {len(documents)} docs into {len(chunks)} chunks")
    return chunks


# -----------------------------
# 3) Embedding Manager
# -----------------------------
class EmbeddingManager:
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.model_name = model_name
        print(f"[Embeddings] Loading embedding model: {model_name}")
        self.model = SentenceTransformer(model_name)
        print(f"[Embeddings] Ready. Dim={self.model.get_sentence_embedding_dimension()}")

    def generate_embeddings(self, texts: List[str]) -> np.ndarray:
        embs = self.model.encode(texts, show_progress_bar=True)
        return np.asarray(embs, dtype=np.float32)


# -----------------------------
# 4) Chroma Vector Store
# -----------------------------
class VectorStore:
    """
    In-memory Chroma collection (fast for experiments).
    Stores: ids, embeddings, documents, metadatas
    """
    def __init__(self, collection_name: str = "txt_documents"):
        self.collection_name = collection_name
        self.client = chromadb.Client()
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        print(f"[Chroma] Collection='{self.collection_name}' count={self.collection.count()}")

    def add_documents(self, documents: List[Any], embeddings: np.ndarray):
        if len(documents) != len(embeddings):
            raise ValueError("Documents and embeddings count mismatch")

        ids, metadatas, texts, embedding_list = [], [], [], []

        for i, (doc, emb) in enumerate(zip(documents, embeddings)):
            doc_id = f"doc_{uuid.uuid4().hex[:10]}"
            ids.append(doc_id)

            md = dict(doc.metadata) if getattr(doc, "metadata", None) else {}
            # Normalize source field
            # LangChain uses "source" with absolute/relative path usually
            src = md.get("source", md.get("source_file", "unknown"))
            md["source_file"] = os.path.basename(src) if isinstance(src, str) else str(src)
            md["chunk_id"] = i
            md["length"] = len(doc.page_content) if getattr(doc, "page_content", None) else 0

            metadatas.append(md)
            texts.append(doc.page_content)
            embedding_list.append(emb.tolist())

        self.collection.add(ids=ids, embeddings=embedding_list, metadatas=metadatas, documents=texts)
        print(f"[Chroma] Added {len(texts)} chunks. Total={self.collection.count()}")


def add_documents_in_batches(vectorstore: VectorStore, chunks: List[Any], embeddings: np.ndarray, batch_size: int = 5000):
    total = len(chunks)
    for i in range(0, total, batch_size):
        batch_chunks = chunks[i:i + batch_size]
        batch_embs = embeddings[i:i + batch_size]
        vectorstore.add_documents(batch_chunks, batch_embs)
        print(f"[Chroma] Added batch {i} → {i + len(batch_chunks)}")


# -----------------------------
# 5) Balanced Retriever (prevents train.txt dominance)
# -----------------------------
class ChromaBalancedRAGRetriever:
    """
    Uses Chroma query() then balances results across source_file.

    - pool_size: retrieve more candidates from Chroma
    - max_per_source: cap how many chunks per file in final results
    - preferred_sources: optionally ensure dev.txt appears if relevant
    """
    def __init__(
        self,
        vector_store: VectorStore,
        embedding_manager: EmbeddingManager,
        pool_size: int = 50,
        max_per_source: int = 2,
        preferred_sources: Optional[List[str]] = None,
    ):
        self.vector_store = vector_store
        self.embedding_manager = embedding_manager
        self.pool_size = int(pool_size)
        self.max_per_source = int(max_per_source)
        self.preferred_sources = preferred_sources or []

        print(f"[Retriever] pool_size={self.pool_size} max_per_source={self.max_per_source} preferred={self.preferred_sources}")

    def retrieve(self, query: str, top_k: int = 5, score_threshold: float = 0.0) -> List[Dict[str, Any]]:
        # query embedding
        q_emb = self.embedding_manager.generate_embeddings([query])[0]

        # pull a larger pool
        results = self.vector_store.collection.query(
            query_embeddings=[q_emb.tolist()],
            n_results=max(top_k, self.pool_size),
        )

        out: List[Dict[str, Any]] = []
        per_src: Dict[str, int] = {}

        if not results.get("documents") or not results["documents"][0]:
            return []

        documents = results["documents"][0]
        metadatas = results["metadatas"][0]
        distances = results["distances"][0]
        ids = results["ids"][0]

        # Chroma cosine distance -> similarity = 1 - distance
        candidates = []
        for doc_id, doc_txt, md, dist in zip(ids, documents, metadatas, distances):
            sim = 1.0 - float(dist)
            candidates.append((sim, doc_id, doc_txt, md, float(dist)))

        # sort high similarity first
        candidates.sort(key=lambda x: x[0], reverse=True)

        # balanced pick
        for sim, doc_id, doc_txt, md, dist in candidates:
            if sim < score_threshold:
                continue
            src = (md or {}).get("source_file", "unknown")
            if per_src.get(src, 0) >= self.max_per_source:
                continue

            out.append({
                "id": doc_id,
                "content": doc_txt,
                "metadata": md,
                "similarity_score": sim,
                "distance": dist,
            })
            per_src[src] = per_src.get(src, 0) + 1
            if len(out) >= top_k:
                break

        # optional: ensure preferred sources get a chance (dev.txt etc.)
        if self.preferred_sources and len(out) < top_k:
            picked_sources = {d["metadata"].get("source_file", "unknown") for d in out}
            for pref in self.preferred_sources:
                if len(out) >= top_k:
                    break
                if pref in picked_sources:
                    continue
                # pick best candidate from that preferred file if present
                best_pref = None
                for sim, doc_id, doc_txt, md, dist in candidates:
                    src = (md or {}).get("source_file", "unknown")
                    if src == pref and sim >= score_threshold:
                        best_pref = (sim, doc_id, doc_txt, md, dist)
                        break
                if best_pref:
                    sim, doc_id, doc_txt, md, dist = best_pref
                    out.append({
                        "id": doc_id,
                        "content": doc_txt,
                        "metadata": md,
                        "similarity_score": float(sim),
                        "distance": float(dist),
                    })
                    picked_sources.add(pref)

        return out


# -----------------------------
# 6) One-call builder for your pipeline
# -----------------------------
def build_chroma_rag(
    data_dir: str,
    embed_model: str = "all-MiniLM-L6-v2",
    collection_name: str = "txt_documents",
    chunk_size: int = 500,
    chunk_overlap: int = 200,
    batch_size: int = 5000,
    pool_size: int = 50,
    max_per_source: int = 2,
    preferred_sources: Optional[List[str]] = None,
):
    docs = load_documents(data_dir)
    chunks = split_documents(docs, chunk_size=chunk_size, chunk_overlap=chunk_overlap)

    emb_mgr = EmbeddingManager(embed_model)
    texts = [c.page_content for c in chunks]
    embs = emb_mgr.generate_embeddings(texts)

    vs = VectorStore(collection_name=collection_name)
    add_documents_in_batches(vs, chunks, embs, batch_size=batch_size)

    retriever = ChromaBalancedRAGRetriever(
        vector_store=vs,
        embedding_manager=emb_mgr,
        pool_size=pool_size,
        max_per_source=max_per_source,
        preferred_sources=preferred_sources,
    )
    return retriever