import time
from typing import Dict, Any

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline, BitsAndBytesConfig


class LLMManager:
    def __init__(
        self,
        model_name: str,
        device_map: str = "auto",
        dtype: str = "auto",
        load_in_4bit: bool = False,
        load_in_8bit: bool = False,
        max_new_tokens: int = 160,
        temperature: float = 0.5,
        do_sample: bool = True,
        trust_remote_code: bool = True,
    ):
        self.model_name = model_name
        self.device_map = device_map
        self.dtype = dtype
        self.load_in_4bit = load_in_4bit
        self.load_in_8bit = load_in_8bit
        self.max_new_tokens = max_new_tokens
        self.temperature = temperature
        self.do_sample = do_sample
        self.trust_remote_code = trust_remote_code
        self.load_model()

    def _resolve_dtype(self):
        if self.dtype == "auto":
            if torch.cuda.is_available():
                major = torch.cuda.get_device_properties(0).major
                return torch.bfloat16 if major >= 8 else torch.float16
            return torch.float32
        return {
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
            "float32": torch.float32,
        }[self.dtype]

    def load_model(self):
        print(f"\nLoading model: {self.model_name}\n")

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_name, trust_remote_code=self.trust_remote_code
        )
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        torch_dtype = self._resolve_dtype()

        quant_config = None
        if self.load_in_4bit or self.load_in_8bit:
            quant_config = BitsAndBytesConfig(
                load_in_4bit=self.load_in_4bit,
                load_in_8bit=self.load_in_8bit,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=torch.float16 if torch_dtype == torch.bfloat16 else torch_dtype,
            )

        model_kwargs = dict(
            low_cpu_mem_usage=True,
            trust_remote_code=self.trust_remote_code,
            device_map=self.device_map if torch.cuda.is_available() else None,
        )
        if quant_config is not None:
            model_kwargs["quantization_config"] = quant_config
        else:
            model_kwargs["torch_dtype"] = torch_dtype

        self.model = AutoModelForCausalLM.from_pretrained(self.model_name, **model_kwargs)

        self.pipe = pipeline(
            "text-generation",
            model=self.model,
            tokenizer=self.tokenizer,
            max_new_tokens=self.max_new_tokens,
            temperature=self.temperature,
            do_sample=self.do_sample,
            return_full_text=False,
        )

        self.is_chat_model = hasattr(self.tokenizer, "chat_template") and self.tokenizer.chat_template is not None
        print("Detected CHAT model" if self.is_chat_model else "Detected COMPLETION model")
        print("Model ready!\n")

    def _format_prompt(self, prompt: str) -> str:
        # Uses chat template if available
        if self.is_chat_model:
            messages = [
                {"role": "system", "content": "Answer the question using the provided context only."},
                {"role": "user", "content": prompt},
            ]
            return self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        return prompt

    def invoke_timed(self, prompt: str) -> Dict[str, Any]:
        formatted_prompt = self._format_prompt(prompt)

        # prompt token count
        try:
            prompt_tokens = len(self.tokenizer.encode(formatted_prompt))
        except Exception:
            prompt_tokens = 0

        # accurate timing on GPU
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        t0 = time.perf_counter()

        out = self.pipe(formatted_prompt)[0]["generated_text"].strip()

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        t1 = time.perf_counter()

        llm_latency_s = t1 - t0

        # output token count
        try:
            output_tokens = len(self.tokenizer.encode(out))
        except Exception:
            output_tokens = 0

        tokens_per_sec = (output_tokens / llm_latency_s) if llm_latency_s > 0 else 0.0

        return {
            "text": out,
            "llm_latency_s": float(llm_latency_s),
            "prompt_tokens": int(prompt_tokens),
            "output_tokens": int(output_tokens),
            "tokens_per_sec": float(tokens_per_sec),
        }

    def invoke(self, prompt: str) -> str:
        return self.invoke_timed(prompt)["text"]