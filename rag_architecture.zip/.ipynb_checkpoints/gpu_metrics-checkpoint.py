from typing import Optional, Tuple

def get_gpu_utilization(gpu_index: int = 0) -> Tuple[Optional[float], Optional[float]]:
    """
    Returns (gpu_util_percent, gpu_mem_percent) for GPU index.
    If NVML isn't available or no GPU -> (None, None)
    """
    try:
        from pynvml import (
            nvmlInit, nvmlShutdown,
            nvmlDeviceGetHandleByIndex,
            nvmlDeviceGetUtilizationRates,
            nvmlDeviceGetMemoryInfo,
        )
        nvmlInit()
        h = nvmlDeviceGetHandleByIndex(gpu_index)
        util = nvmlDeviceGetUtilizationRates(h)
        mem = nvmlDeviceGetMemoryInfo(h)
        gpu_util = float(util.gpu)  # %
        gpu_mem = float(mem.used / mem.total * 100.0) if mem.total else None
        nvmlShutdown()
        return gpu_util, gpu_mem
    except Exception:
        return None, None