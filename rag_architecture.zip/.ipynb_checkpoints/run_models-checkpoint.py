# run_models.py
import argparse
import pandas as pd
from dataclasses import asdict

from llm_manager import LLMManager
from rag_eval import evaluate_rag
from rag_retriever_chroma import build_chroma_rag


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--model", type=str, default="Qwen/Qwen2.5-72B-Instruct")
    parser.add_argument("--data_dir", type=str, default="/projectnb/cs585/students/siddhank/data_research/data")

    # embedding + chunking
    parser.add_argument("--embed_model", type=str, default="all-MiniLM-L6-v2")
    parser.add_argument("--chunk_size", type=int, default=500)
    parser.add_argument("--chunk_overlap", type=int, default=200)
    parser.add_argument("--batch_size", type=int, default=5000)

    # retrieval behavior
    parser.add_argument("--top_k", type=int, default=3)
    parser.add_argument("--min_score", type=float, default=0.0)

    # balanced retrieval controls (prevents train.txt dominance)
    parser.add_argument("--pool_size", type=int, default=50)
    parser.add_argument("--max_per_source", type=int, default=2)
    parser.add_argument("--preferred_sources", type=str, default="dev.txt")

    # generation
    parser.add_argument("--max_new_tokens", type=int, default=160)
    parser.add_argument("--temperature", type=float, default=0.5)
    parser.add_argument("--do_sample", action="store_true")
    parser.add_argument("--no_do_sample", dest="do_sample", action="store_false")
    parser.set_defaults(do_sample=True)

    # quantization flags (default OFF, as you wanted earlier)
    parser.add_argument("--load_in_4bit", action="store_true")
    parser.add_argument("--no_load_in_4bit", dest="load_in_4bit", action="store_false")
    parser.set_defaults(load_in_4bit=False)

    parser.add_argument("--load_in_8bit", action="store_true")
    parser.add_argument("--no_load_in_8bit", dest="load_in_8bit", action="store_false")
    parser.set_defaults(load_in_8bit=False)

    # eval / infra
    parser.add_argument("--max_claims", type=int, default=10)
    parser.add_argument("--gpu_index", type=int, default=0)
    parser.add_argument("--out_csv", type=str, default="rag_eval.csv")

    # cost knobs
    parser.add_argument("--gpu_cost_per_hour", type=float, default=3.0)
    parser.add_argument("--cpu_cost_per_hour", type=float, default=2.0)
    parser.add_argument("--fixed_cost_usd", type=float, default=2.0)

    args = parser.parse_args()

    preferred_sources = [s.strip() for s in (args.preferred_sources or "").split(",") if s.strip()]

    # 1) Build RAG retriever using notebook-style components (loader+chunking+chroma)
    rag_retriever = build_chroma_rag(
        data_dir=args.data_dir,
        embed_model=args.embed_model,
        collection_name="txt_documents",
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
        batch_size=args.batch_size,
        pool_size=args.pool_size,
        max_per_source=args.max_per_source,
        preferred_sources=preferred_sources,
    )

    # 2) LLM
    llm_manager = LLMManager(
        model_name=args.model,
        device_map="auto",
        dtype="auto",
        load_in_4bit=args.load_in_4bit,
        load_in_8bit=args.load_in_8bit,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
        do_sample=args.do_sample,
        trust_remote_code=True,
    )

    # 3) Queries (edit freely)
    test_queries = [
        {"query": "Background briefing on ABC Radio?"},
        # {"query": "Who is the CEO of the company ABC Radio?"},
        # {"query": "What is a machine?"},
        # {"query": "Summarize key dates mentioned?"},
    ]

    # 4) Evaluate (your same pipeline)
    rows, detailed = evaluate_rag(
        queries=test_queries,
        retriever=rag_retriever,
        rag_llm=llm_manager,
        judge_llm=llm_manager,
        top_k=args.top_k,
        min_score=args.min_score,
        max_claims=args.max_claims,
        gpu_index=args.gpu_index,
        gpu_cost_per_hour=args.gpu_cost_per_hour,
        cpu_cost_per_hour=args.cpu_cost_per_hour,
        fixed_cost_usd=args.fixed_cost_usd,
    )

    # 5) DataFrame
    df = pd.DataFrame([asdict(r) for r in rows])

    cols = [
        "query",
        "answer",
        "hallucination_rate",
        "groundedness_score",
        "answer_relevance_1to5",
        "context_relevance_1to5",
        "confidence",
        "response_time_s",
        "llm_latency_s",
        "gpu_throughput_toks_per_s",
        "eff_gpu_throughput",
        "gpu_util_percent",
        "gpu_mem_percent",
        "total_deployment_cost_usd",
        "top_source",
    ]
    df_view = df[cols]
    print("\n=== RESULTS ===")
    print(df_view)

    df_view.to_csv(args.out_csv, index=False)
    print(f"\nSaved CSV: {args.out_csv}")


if __name__ == "__main__":
    main()