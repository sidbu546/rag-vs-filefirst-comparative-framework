# rag_core.py
import time
from typing import Dict, Any


def now() -> float:
    return time.perf_counter()


def _to_text(x):
    if x is None:
        return ""
    if isinstance(x, str):
        return x
    if isinstance(x, dict):
        for k in ("answer", "output", "text", "content", "generated_text", "response"):
            if k in x and isinstance(x[k], str):
                return x[k]
        return str(x)
    if hasattr(x, "content") and isinstance(getattr(x, "content"), str):
        return x.content
    if isinstance(x, list) and x:
        return _to_text(x[0])
    return str(x)


def _call_llm(llm, prompt: str) -> str:
    if hasattr(llm, "invoke"):
        return _to_text(llm.invoke(prompt))
    if hasattr(llm, "generate"):
        return _to_text(llm.generate(prompt))
    if callable(llm):
        return _to_text(llm(prompt))
    raise TypeError("llm must provide .invoke(prompt), .generate(prompt), or be callable.")


def _call_llm_timed(llm, prompt: str) -> Dict[str, Any]:
    """
    Uses llm.invoke_timed if available (recommended). Otherwise falls back to plain invoke.
    Returns dict with keys at least: text, llm_latency_s, output_tokens, tokens_per_sec.
    """
    if hasattr(llm, "invoke_timed"):
        out = llm.invoke_timed(prompt)
        # ensure expected keys exist
        out.setdefault("llm_latency_s", None)
        out.setdefault("output_tokens", None)
        out.setdefault("tokens_per_sec", None)
        return out

    # fallback
    t0 = time.perf_counter()
    text = _call_llm(llm, prompt)
    t1 = time.perf_counter()
    return {"text": text, "llm_latency_s": float(t1 - t0), "output_tokens": None, "tokens_per_sec": None}


def rag_advanced(
    query: str,
    retriever,
    llm,
    top_k: int,
    min_score: float = 0.0,
    return_context: bool = False,
    debug: bool = True,
):
    """
    Open-domain RAG:
      - Uses retrieved context if relevant
      - If context is insufficient or retrieval empty, answers using general knowledge
      - Never forces "I don't know"

    Returns:
      answer, sources, confidence,
      context (optional),
      timings: retrieve_s, llm_s, total_s, output_tokens, tokens_per_sec
    """
    timings: Dict[str, Any] = {}
    t_total0 = now()

    # -----------------
    # Retrieve
    # -----------------
    t0 = now()
    results = retriever.retrieve(query, top_k=top_k, score_threshold=min_score)
    timings["retrieve_s"] = now() - t0

    # debug retrieval
    if debug:
        print("\n[DEBUG] Query:", query)
        print("[DEBUG] Retrieved:", len(results), f"(top_k={top_k}, score_threshold={min_score})")
        for r in results[: min(3, len(results))]:
            md = (r.get("metadata") or {})
            print(
                "  score=", float(r.get("similarity_score", 0.0)),
                "source=", md.get("source_file", md.get("source", "unknown")),
                "chunk_id=", md.get("chunk_id", "NA")
            )

    # -----------------
    # No retrieval -> answer normally
    # -----------------
    if not results:
        prompt = f"""You are a helpful assistant.

Answer the question using your general knowledge.
Be concise and informative.

Question: {query}

Answer:
"""
        llm_out = _call_llm_timed(llm, prompt)
        answer = (llm_out.get("text") or "").strip()

        timings["llm_s"] = float(llm_out.get("llm_latency_s") or 0.0)
        timings["output_tokens"] = llm_out.get("output_tokens")
        timings["tokens_per_sec"] = float(llm_out.get("tokens_per_sec") or 0.0)
        timings["total_s"] = now() - t_total0

        out = {
            "answer": answer,
            "sources": [],
            "confidence": 0.0,
            "timings": timings,
        }
        if return_context:
            out["context"] = ""
        return out

    # -----------------
    # Build context + sources
    # -----------------
    context = "\n\n".join(doc.get("content", "") for doc in results)

    sources = []
    for doc in results:
        md = doc.get("metadata", {}) or {}
        content = doc.get("content", "") or ""
        sources.append({
            "source": md.get("source_file", md.get("source", "unknown")),
            "page": md.get("page", "unknown"),
            "chunk_id": md.get("chunk_id", None),
            "score": float(doc.get("similarity_score", 0.0)),
            "preview": (content[:300] + "...") if len(content) > 300 else content,
        })

    confidence = max(float(doc.get("similarity_score", 0.0)) for doc in results)

    # -----------------
    # Open-domain prompt (uses context if helpful)
    # -----------------
    prompt = f"""You are a helpful assistant.

Use the provided context if it is relevant.
If the context is insufficient, answer using your general knowledge.
Be concise and informative.

Context:
{context}

Question: {query}

Answer:
"""

    llm_out = _call_llm_timed(llm, prompt)
    answer = (llm_out.get("text") or "").strip()

    timings["llm_s"] = float(llm_out.get("llm_latency_s") or 0.0)
    timings["output_tokens"] = llm_out.get("output_tokens")
    timings["tokens_per_sec"] = float(llm_out.get("tokens_per_sec") or 0.0)
    timings["total_s"] = now() - t_total0

    out = {
        "answer": answer,
        "sources": sources,
        "confidence": confidence,
        "timings": timings,
    }
    if return_context:
        out["context"] = context
    return out